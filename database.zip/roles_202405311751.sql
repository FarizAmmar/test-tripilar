INSERT INTO test_tripilar.roles (role_name,created_at,updated_at) VALUES
	 ('ADMIN','2024-05-31 09:53:43','2024-05-31 09:53:43'),
	 ('MANAGER','2024-05-31 09:53:43','2024-05-31 09:53:43'),
	 ('SUPERVISOR','2024-05-31 09:53:43','2024-05-31 09:53:43');
