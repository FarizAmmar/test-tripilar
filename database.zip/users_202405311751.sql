INSERT INTO test_tripilar.users (name,email,email_verified_at,password,company_id,role_id,remember_token,created_at,updated_at) VALUES
	 ('Rachel Langosh','jennie81@example.org','2024-05-31 09:53:43','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',2,3,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Prof. Triston Stanton Jr.','letha.gusikowski@example.com','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',1,3,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Easter Lockman','tcollier@example.com','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',1,1,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Gabrielle Stiedemann','sterling.murray@example.com','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',2,3,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Harmony Schroeder','bartell.jadyn@example.org','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',1,1,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Timmothy Graham','toni64@example.com','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',3,3,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Pasquale Dickens','annabell.kozey@example.net','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',1,2,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Ellen Breitenberg','elizabeth.lueilwitz@example.com','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',2,2,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Prof. Geo Kassulke','fstokes@example.com','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',2,3,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Cicero Bosco Jr.','fadel.gustave@example.org','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',1,2,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44');
INSERT INTO test_tripilar.users (name,email,email_verified_at,password,company_id,role_id,remember_token,created_at,updated_at) VALUES
	 ('Prof. Major Turner Jr.','minnie.jacobi@example.com','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',2,3,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Prof. Terrell Thompson MD','greenfelder.dereck@example.org','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',1,1,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Kayla Mertz II','paucek.cordelia@example.net','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',3,3,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Miss Ashtyn Monahan','edmond76@example.org','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',2,1,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Dr. Stone Kihn I','kfisher@example.com','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',3,1,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Era Bogan','cecelia.morissette@example.com','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',1,3,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Jannie Bogisich','prudence.beer@example.net','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',1,2,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Camila Glover','cronin.teagan@example.com','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',1,2,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Danika Casper','kamren76@example.org','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',3,1,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Pattie Paucek II','dolores.gusikowski@example.com','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',1,2,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44');
INSERT INTO test_tripilar.users (name,email,email_verified_at,password,company_id,role_id,remember_token,created_at,updated_at) VALUES
	 ('Chelsie Volkman','maeve.mcclure@example.org','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',1,3,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Jaeden Schmidt Jr.','qschuppe@example.org','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',3,2,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Eladio Krajcik','brant47@example.org','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',2,3,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Kattie Crooks','sigurd.moore@example.org','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',1,3,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Dr. Burdette Purdy','adrianna.corwin@example.net','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',2,1,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Gregg Schmidt','sschmeler@example.com','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',2,3,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Miss Earlene Beatty','stephon80@example.org','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',2,3,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Afton Daniel','myrtie74@example.org','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',1,2,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Nicholas Konopelski IV','waelchi.arvilla@example.org','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',2,3,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Mr. Orion Sporer IV','stokes.bernard@example.com','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',3,2,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44');
INSERT INTO test_tripilar.users (name,email,email_verified_at,password,company_id,role_id,remember_token,created_at,updated_at) VALUES
	 ('Ruth Reinger','sbeahan@example.net','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',1,2,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Kaylah Bradtke MD','pstroman@example.com','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',3,3,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Ashlynn Stanton I','annie.renner@example.org','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',2,1,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Jalyn Gottlieb','orpha.haag@example.org','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',2,1,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Brock Torp V','preston65@example.org','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',3,1,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Lucious McDermott','micah.nikolaus@example.com','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',1,3,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Dr. Lulu Lind','kling.courtney@example.com','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',1,3,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Vernon Schinner','aylin.mante@example.net','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',2,1,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Candace Jones','rutherford.ashleigh@example.org','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',2,1,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Adelbert Hoeger','mosciski.grayce@example.com','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',2,1,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44');
INSERT INTO test_tripilar.users (name,email,email_verified_at,password,company_id,role_id,remember_token,created_at,updated_at) VALUES
	 ('Lexie Schroeder','llittle@example.com','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',2,1,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Darrick Quitzon','durward58@example.org','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',2,1,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Ms. Natalia Feeney','hassie.oreilly@example.com','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',1,2,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Ona Farrell PhD','gaylord.orval@example.com','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',2,1,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Jaylon Wunsch','ukunde@example.com','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',3,2,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Gina Bosco DDS','josh34@example.com','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',1,3,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Alvina Anderson','savion56@example.org','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',3,2,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Miss Maegan Veum','bergstrom.emerald@example.org','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',1,3,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Hilma Welch','glindgren@example.org','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',2,2,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44'),
	 ('Providenci Schmidt V','gulgowski.candice@example.com','2024-05-31 09:53:44','$2y$12$MsBUWzxXA59rDJQwi5StJedWLKzNEMgnW2eEavTd/VS2qNRiEUZDK',2,2,NULL,'2024-05-31 09:53:44','2024-05-31 09:53:44');
INSERT INTO test_tripilar.users (name,email,email_verified_at,password,company_id,role_id,remember_token,created_at,updated_at) VALUES
	 ('Fariz Ammar','f.ammarsyq12@gmail.com','2024-05-31 10:32:26','$2y$12$CdKKwNLHbP9VUwBTs9EHw.M8GOO8ZnzEbwgDEKdpTpcVeF2abYO/u',1,1,NULL,'2024-05-31 10:32:26','2024-05-31 10:38:18');
