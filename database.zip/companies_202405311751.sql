INSERT INTO test_tripilar.companies (company_name,created_at,updated_at) VALUES
	 ('PT. XYZ','2024-05-31 09:53:43','2024-05-31 09:53:43'),
	 ('PT. XYZ-1','2024-05-31 09:53:43','2024-05-31 09:53:43'),
	 ('PT. XYZ-2','2024-05-31 09:53:43','2024-05-31 09:53:43');
